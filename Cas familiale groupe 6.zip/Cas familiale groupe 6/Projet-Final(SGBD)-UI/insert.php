<?php

include_once('connection.php');

 //fonction pour l'insertion dans la table type_revenu

 function Insert_type_revenu(){
    $con = Connect();
    //Requete SQL
    $req = 'INSERT INTO `type_revenu`(`nom_type_revenu`) VALUES (:t)';
    //preparation de la requete
    $stm = $con->prepare($req);
    //passage des valeurs
    $stm->bindvalue(':t',$nom);
   //execution de la requete
    $stm->execute();

   
 }
 
 //Insert_type_revenu("Don");


 //fonction pour l'insertion dans la table source_revenu



 function Insert_source_revenu($nom){
    $con = Connect();
    //Requete SQL
    $req = 'INSERT INTO `source_revenu`(`nom_source`) VALUES (:t)';
    //preparation de la requete
    $stm = $con->prepare($req);
    //passage des valeurs
    $stm->bindvalue(':t',$nom);
   //execution de la requete
    $stm->execute();

   
 }
 //Insert_source_revenu("Parent");

 //fonction pour l'insertion dans la table revenu

 function Insert_revenu($date,$montant){
    $con = Connect();
    //Requete SQL
    $req = 'INSERT INTO `revenu`(`date_revenu`,`montant_r`) VALUES (:d,:m)';
    //preparation de la requete
    $stm = $con->prepare($req);
    //passage des valeurs
    
    $stm->bindvalue(':d',$date);
    $stm->bindvalue(':m',$montant);
    

   //execution de la requete
    $stm->execute();

   
 }
//Insert_revenu('2021-05-19',250);


//fonction pour l'insertion dans la table type_depense

function Insert_type_depense($nom){
    $con = Connect();
    //Requete SQL
    $req = 'INSERT INTO `type_depense`(`nom_type_depense`) VALUES (:t)';
    //preparation de la requete
    $stm = $con->prepare($req);
    //passage des valeurs
    $stm->bindvalue(':t',$nom);
   //execution de la requete
    $stm->execute();

   
 }
 
 
 //Insert_type_depense("Remboursement");


 //fonction pour l'insertion dans la table objet_depense



 function Insert_objet_depense($nom){
    $con = Connect();
    //Requete SQL
    $req = 'INSERT INTO `objet_depense`(`nom_objet`) VALUES (:t)';
    //preparation de la requete
    $stm = $con->prepare($req);
    //passage des valeurs
    $stm->bindvalue(':t',$nom);
   //execution de la requete
    $stm->execute();

   
 }
// Insert_objet_depense("Banque");

 //fonction pour l'insertion dans la table depense


 function Insert_depense($date,$montant){
    $con = Connect();
    //Requete SQL
    $req = 'INSERT INTO `depense`(`date_depense`,`montant_d`) VALUES (:d,:m)';
    //preparation de la requete
    $stm = $con->prepare($req);
    //passage des valeurs
    
    $stm->bindvalue(':d',$date);
    $stm->bindvalue(':m',$montant);
    

   //execution de la requete
    $stm->execute();

   
 }
//Insert_depense('2021-05-19',300);
 

//fonction pour l'insertion dans la table epargne


function Insert_epargne($montant){
    $con = Connect();
    //Requete SQL
    $req = 'INSERT INTO `epargne`(`montant`) VALUES (:m)';
    //preparation de la requete
    $stm = $con->prepare($req);
    //passage des valeurs
    $stm->bindvalue(':m',$montant);
    

   //execution de la requete
    $stm->execute();

   
 }
 //Insert_epargne(250.78);
?>