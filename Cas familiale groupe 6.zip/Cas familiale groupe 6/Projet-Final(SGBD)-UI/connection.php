<?php
    function Connect(){
        $dsn = 'mysql:host=localhost; dbname=gestion_familiale; port=3306';
        $usr = 'root';
        $pswd = 'jmg141983';
                     
        try{
            $con = new PDO($dsn,$usr,$pswd);
            if($con){ 
                

                           
                return $con;
                
            }
            
            
        }catch(PDOException $e){
            die("Erreur de connexion: ".$e->getMessage());
        }
        
    } 
    
   

    
    
?>
