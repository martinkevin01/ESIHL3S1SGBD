
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion familiale de m&#233;nage</title>
    <style type="text/css">
    BODY{
        display:flex;
        flex-direction:row-reverse;
        justify-content:space-between;
        align-items:center;
    }
    ARTICLE {
    width: 550PX;
    

}
    #chart-container {
    width: 100%;
    height: auto;
}
</style>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/Chart.min.js"></script>

</head>


<body>

<div>
<article>
<h2>Rapport Graphique</h2>
<div id="chart-container">
        <canvas id="graphCanvas"></canvas>
    </div>

    <script>
        $(document).ready(function () {
            showGraph();
        });


        function showGraph()
        {
            {
                $.post("data_revenu.php",
                function (data)
                {
                    console.log(data);
                     var revenu = [];
                    var montant = [];

                    for (var i in data) {
                        revenu.push(data[i].date_revenu);
                        montant.push(data[i].montant_r);
                    }

                    var chartdata = {
                        labels: revenu,
                        datasets: [
                            {
                                label: 'Revenu',
                                backgroundColor: '#49e2ff',
                                borderColor: '#46d5f1',
                                borderWidth:1,
                                hoverBorderWidth:4,
                                hoverBorderColor:'#000',
                                borderColor:'#777',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: montant
                            }
                        ]
                    };

                    var graphTarget = $("#graphCanvas");

                    var barGraph = new Chart(graphTarget, {
                        type: 'line',
                        data: chartdata
                    });
                });
            }
        }
        </script>
</article>

<article>
<h2>Rapport Graphique Comparatif</h2>
<div id="chart-container">
        <canvas id="graphCanvas1"></canvas>
    </div>

    <script>
        $(document).ready(function () {
            showGraph1();
        });


        function showGraph1

()

        {
            {
                $.post("mixedchart.php",
                function (data)
                {
                   // console.log(data);
                var dataRevenu = (data[1].slice(0,));
                var dataDepense = (data[0].slice(0,));
               // console.log(dataDepense);
                     var revenu = [];
                    var montantRevenu = [];
                    var depense = [];
                    var montantDepense = [];

                    for (var i in dataRevenu) {
                        revenu.push(dataRevenu[i].date_revenu);
                       montantRevenu.push(dataRevenu[i].montant_r);
                       
                      // var month = revenu[0].getMonth();
                    }
                    for (var i in dataDepense){
                        montantDepense.push(dataDepense[i].montant_d);
                        depense.push(dataDepense[i].date_depense);

                    }
                    
                  //console.log(revenu[0]);
                  
                  var month = new Date(revenu[1]);


                   console.log(month.getMonth()+1);
                 
                    //console.log(month);

                    var chartdata = {
                        labels: depense,
                        datasets: [
                            {
                                label: 'Revenu',
                                backgroundColor: '#49e2ff',
                                borderColor: '#46d5f1',
                                borderWidth:1,
                                fill:'fasle',
                                hoverBorderWidth:4,
                                hoverBorderColor:'#000',
                                borderColor:'#777',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: montantRevenu
                            },
                            {
                                 label: "Depense",
                                 //new option, barline will default to bar as that what is used to create the scale
                                type: "line",
                                backgroundColor: 'red',
                                borderColor: 'black',
                                borderWidth:1,
                                fill:'false',
                                hoverBorderWidth:4,
                                hoverBorderColor:'#000',
                                borderColor:'#777',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: montantDepense
                            }
                            
                        ]
                    };

                    var graphTarget = $("#graphCanvas1");

                    var barGraph = new Chart(graphTarget, {
                        type:'line',
                        data: chartdata
                    });
                });
            }
        }
        </script>
</article>
</div>

<div>
        <h1>Saisissez les d&#233;tails de vos revenus ici!</h1>
    
   

    
        <form action="revenu.php" method="post">
            <label for="type_r">Type de Revenu:</label>
            <br>
            <br>
           <!-- <input type="text" name="type_r" id="type_r">-->

           <select name="type_r" id="type_r">
                <option value="salaire">Salaire</option>
                <option value="don">Don</option>
                <option value="emprunt">Emprunt</option>
            </select>
            
            
            <br> <br>
            <br>
            <br>
            <br>
            <br>
            <br>
           

           <!-- <button type="submit" name="detail_revenu">Valider</button>-->
        
        
        <br><br><br>

        
            <label for="source_r">Source de Revenu:</label>
            <br>
            <br>

           <!-- <input type="text" name="source_r" id="source_r">-->

           <select name="source_r" id="source_r">
                <option value="employeur">Employeur</option>
                <option value="ami ou parent">Ami(s) ou Parent(s)</option>
                <option value="banque">Banque</option>
            </select>
            <br> <br>
            <br>
            <br>
            <br>
            <br>
            <br>
           

            

        

        
        <label for="date_revenu">Date du Revenu:</label><br><br>
        <input type="date" name="date_revenu" id="date_revenu">
        <br>
        <br>
        <label for="montant">Montant: (en gourdes)</label><br><br>
        <input type="number" name="montant" id="montant">
        <br>
        
        
        <br><br>

        <button type="submit" name="detail_revenu">Valider</button>
        <button type="button" onclick="self.location.href='index.php'">Retour</button>
        <button type="button" onclick="self.location.href='liste_revenu.php'">Voir la liste de vos revenus</button>

    </form>



   

   
    
    </div>

    

    
    
    


    <?php

    
        include_once('connection.php');

        $con = Connect();


        if(isset($_POST['detail_revenu'])){

        
        //Insertion dans la table type de revenu

        $type= $_POST['type_r'];

        //Requete SQL
        $req1 = "CALL `insert_type_revenu_pro`(:nom);";

        //preparation de la requete
        $stm1 = $con->prepare($req1);

        //Passage des valeurs
        $stm1->bindParam(":nom",$type);

        //execution de la requete
        $stm1->execute();
    



        //Insertion dans la table source de revenu

        $source= $_POST['source_r'];

         //Requete SQL
         $req2 = "CALL `insert_source_revenu_pro`(:nom);";

         //preparation de la requete
         $stm2 = $con->prepare($req2);
 
         //Passage des valeurs
         $stm2->bindParam(":nom",$source);
         
         //execution de la requete
         $stm2->execute();
     
 


        //Insertion dans la table revenu
       
        $date_revenu=$_POST['date_revenu'];
        $montant=$_POST['montant'];

         //Requete SQL
         $req3 = "CALL `insert_revenu_pro`(:date_re,:amount);";

         //preparation de la requete
         $stm3 = $con->prepare($req3);
 
         //Passage des valeurs
         $stm3->bindParam(":date_re",$date_revenu);
        $stm3->bindParam(":amount",$montant);
         
         //execution de la requete
         $stm3->execute();
     
 

        

    }

 
    ?>
    
    

    
</body>
</html>