<?php
header('Content-Type: application/json');
$dsn = 'mysql:host=localhost; gestion_familiale; port=3306';
$usr = 'root';
$pswd = 'jmg141983';
$conn = mysqli_connect("localhost","root",$pswd,"gestion_familiale");

$sqlQueryRevenu = "SELECT id_revenu,date_revenu,montant_r FROM revenu ORDER BY id_revenu";
$sqlQueryDepense = "SELECT id_depense,date_depense,montant_d FROM depense ORDER BY id_depense";
$sqlQueryEpargne = "SELECT id_epargne,montant,id_revenu FROM epargne ORDER BY id_epargne";

$resultRevenu = mysqli_query($conn,$sqlQueryRevenu);
$resultDepense =mysqli_query($conn,$sqlQueryDepense);
$resultEpargne =mysqli_query($conn,$sqlQueryEpargne);


$dataRevenu = array();
foreach ($resultRevenu as $row) {
	$dataRevenu[] = $row;
}

$dataDepense = array();
foreach ($resultDepense as $row){
    $dataDepense[] = $row;
}
$dataEpargne = array();
foreach ($resultEpargne as $row) {
	$dataEpargne[] = $row;
}

mysqli_close($conn);
$data = array($dataDepense,$dataRevenu,$dataEpargne);
//echo json_encode($dataRevenu);
//echo json_encode($dataDepense);
echo json_encode($data);

?>