<?php
header('Content-Type: application/json');
$dsn = 'mysql:host=localhost; gestion_familiale; port=3306';
$usr = 'root';
$pswd = 'jmg141983';
$conn = mysqli_connect("localhost","root",$pswd,"gestion_familiale");

$sqlQuery = "SELECT id_depense,date_depense,montant_d FROM depense ORDER BY id_depense";

$result = mysqli_query($conn,$sqlQuery);

$data = array();
foreach ($result as $row) {
	$data[] = $row;
}

mysqli_close($conn);

echo json_encode($data);
?>
