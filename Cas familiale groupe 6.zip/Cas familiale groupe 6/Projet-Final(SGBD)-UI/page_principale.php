<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion familiale de m&#233;nage</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div>
    <div>

<div class="conteneur1">

<form action="page_principale.php" method="post" class="conteneur2">

<button type="button" name="choix1" class="choix_x" onclick="self.location.href='revenu.php'">Revenu</button>
<button type="button" name="choix2"  class="choix_x" onclick="self.location.href='depense.php'">D&#233;pense</button>
<button type="button" name="choix3" onclick="self.location.href='epargne.php'"  class="choix_x">&#201;pargne</button>


</form>
</div>
    
</body>


<?php

//code php pour le traitement de l'information

/*$url=include_once('revenu.php');
if(isset($_POST["choix1"])){

    header(Location ($url));
    Exit();

}*/





?>

</html>