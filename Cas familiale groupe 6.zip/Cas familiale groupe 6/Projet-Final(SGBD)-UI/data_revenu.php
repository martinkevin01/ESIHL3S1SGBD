<?php
header('Content-Type: application/json');
$dsn = 'mysql:host=localhost; gestion_familiale; port=3306';
$usr = 'root';
$pswd = 'jmg141983';
$conn = mysqli_connect("localhost","root",$pswd,"gestion_familiale");

$sqlQuery = "SELECT id_revenu,date_revenu,montant_r FROM revenu ORDER BY id_revenu";
//$sqlQuery = "SELECT id_revenu, montant_r, DATE_FORMAT(date_revenu , '%m') AS month_group FROM revenu GROUP BY MONTH(date_revenu) ASC";


$result = mysqli_query($conn,$sqlQuery);

$data = array();
foreach ($result as $row) {
	$data[] = $row;
}

mysqli_close($conn);

echo json_encode($data);
?>
