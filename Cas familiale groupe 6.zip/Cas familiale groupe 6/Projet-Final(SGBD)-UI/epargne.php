<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion familiale de m&#233;nage</title>
    <style type="text/css">
    BODY{
        display:flex;
        flex-direction:row-reverse;
        justify-content:space-between;
        align-items:center;
    }
    ARTICLE {
    width: 550PX;
    

}
    #chart-container {
    width: 100%;
    height: auto;
}
</style>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/Chart.min.js"></script>
</head>
<body>
<div>
<article>
<h2>Rapport Graphique</h2>
<div id="chart-container">
        <canvas id="graphCanvas"></canvas>
    </div>

    <script>
        $(document).ready(function () {
            showGraph();
        });


        function showGraph()
        {
            {
                $.post("mixedchart.php",
                function (data)
                {
                    var dataRevenu = (data[1].slice(0,));
                var dataEpargne = (data[2].slice(0,));
               // console.log(dataDepense);
                     var revenu = [];
                    var montantRevenu = [];
                    var epargne = [];
                    var montantEpargne = [];

                    for (var i in dataRevenu) {
                        revenu.push(dataRevenu[i].date_revenu);
                       montantRevenu.push(dataRevenu[i].montant_r);
                       
                      // var month = revenu[0].getMonth();
                    }
                    for (var i in dataEpargne){
                        montantEpargne.push(dataEpargne[i].montant);
                        

                    }
                    var chartdata = {
                        labels: revenu,
                        datasets: [
                            {
                                label: 'Epargne',
                                backgroundColor: 'Green',
                                borderColor: '#46d5f1',
                                borderWidth:1,
                                hoverBorderWidth:4,
                                hoverBorderColor:'#000',
                                borderColor:'#777',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: montantEpargne
                            }
                        ]
                    };

                    var graphTarget = $("#graphCanvas");

                    var barGraph = new Chart(graphTarget, {
                        type: 'line',
                        data: chartdata
                    });
                });
            }
        }
        </script>
</article>
</div>


<form action="epargne.php" method="post">
<h1>Saisissez le montant que vous voulez &#233;pargner de vos revenus ici :</h1>

<label for="montant">Montant &#224;  &#233;pargner: (en gourdes)</label><br><br>

<input type="text" name="montant" id="montant">

<button type="submit" name="epargne">Valider</button><br>
<button type="button" onclick="self.location.href='index.php'">Retour</button>


</form>

<?php

    
        include_once('connection.php');
        $con = Connect();


        

        if(isset($_POST['epargne'])){

            //Fonction pour l'insertion dans la table epargne

            function insert_e(){
                $con = Connect();
            
                
                $montant=$_POST['montant'];
            
                //Requete SQL
                $req = "CALL `insert_epargne_pro`(:amount);";
            
                //preparation de la requete
                $stm = $con->prepare($req);
            
                //Passage des valeurs
                
                $stm->bindvalue(":amount",$montant);
            
                //execution de la requete
                $stm->execute();
            
            }
            
            
            $montant=$_POST['montant'];
            
            //Recuperation des montants se trouvant dans la table revenu
            //afin de faire leur somme
            $sql_revenu = "CALL `select_revenu`();";
            
            $stm_revenu = $con->prepare($sql_revenu);
            
            $stm_revenu->execute();
            
            $revenus=$stm_revenu->fetchAll(PDO::FETCH_ASSOC);
            
            $somme_revenu=0;
            
            foreach($revenus as $revenu){
            
                $somme_revenu = $somme_revenu + $revenu['montant_r'];
            
            
            }
            //Recuperation des montants dans la table depense
            //afin de faire leur somme
            $sql_depense = "CALL `select_depense`();";
            
            $stm_depense = $con->prepare($sql_depense);
            
            $stm_depense->execute();
            
            $depenses=$stm_depense->fetchAll(PDO::FETCH_ASSOC);
            
            $somme_depense = 0;
            
            foreach($depenses as $depense){
            
                $somme_depense=$somme_depense + $depense['montant_d'];
            
            }
            //Le montant disponible est le montant total des revenus moins
            //le montant total des depenses effectues 
                $montant_dispo=$somme_revenu-$somme_depense;
            
                //Si l'utilisateur saisi un montant superieur
                //au montant disponible
                //Il est tout de suite alerte qu'il ne pourra pas en epargner
                //autant car il n'en dispose pas
                //parcontre, si le montant a epargner est strictement inf 
                //au montant dispo, il pourra.
                
                if($montant>=$montant_dispo){
                    echo "Vous ne pouvez pas epargner autant d'argent car vous n'en disposez pas!";
                }else{
            
                    //appel a la fonction qui fait l'insertion dans la table epargne
                    insert_e();
                }
            
               

           

       
       

            
        
           
        
 }

 
?>
    
    
    
</body>
</html>