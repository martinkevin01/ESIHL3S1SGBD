<?php
include_once('connection.php');

$con=Connect();

$sql = "CALL `select_revenu`();";

$stm = $con->prepare($sql);

$stm->execute();

$revenus=$stm->fetchAll(PDO::FETCH_ASSOC);

//print_r($revenus);

?>










<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion familiale de m&#233;nage</title>
</head>
<body>
<div>

<h3>La liste de vos revenus:</h3>

    <ul>

    <?php foreach($revenus as $revenu):?>

    <li>
    <?=$revenu['date_revenu']?> - <?=$revenu['montant_r']?> gourdes
    
    </li>

    <?php endforeach;?>
    
    </ul>
    <br>
    <br>
    <button type="button" onclick="self.location.href='revenu.php'">Retour</button>
    

</div>
    
</body>
</html>