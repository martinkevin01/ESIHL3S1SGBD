
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion familiale de menage</title>
    <style type="text/css">
    BODY{
        display:flex;
        flex-direction:row-reverse;
        justify-content:space-between;
        align-items:center;
    }
    ARTICLE {
    width: 550PX;
    

}
    #chart-container {
    width: 100%;
    height: auto;
}
</style>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/Chart.min.js"></script>

</head>


<body>
<div id="graph">

<article>
<h2> Rapport graphique</h2>
<div id="chart-container">
        <canvas id="graphCanvas"></canvas>
    </div>

    <script>
        $(document).ready(function () {
            showGraph();
        });


        function showGraph()
        {
            {
                $.post("data_depense.php",
                function (data)
                {
                    console.log(data);
                     var depense = [];
                    var montant = [];

                    for (var i in data) {
                        depense.push(data[i].date_depense);
                        montant.push(data[i].montant_d);
                    }

                    var chartdata = {
                        labels: depense,
                        datasets: [
                            {
                                label: 'Depense',
                                backgroundColor: 'red',
                                borderColor: '#46d5f1',
                                borderWidth:1,
                                hoverBorderWidth:4,
                                hoverBorderColor:'#000',
                                borderColor:'#777',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: montant
                            }
                        ]
                    };

                    var graphTarget = $("#graphCanvas");

                    var barGraph = new Chart(graphTarget, {
                        type: 'line',
                        data: chartdata
                    });
                });
            }
        }
        </script>
</article>


<article>
<h2>Rapport Graphique Comparatif</h2>
<div id="chart-container">
        <canvas id="graphCanvas1"></canvas>
    </div>

    <script>
        $(document).ready(function () {
            showGraph1();
        });

        var month = [];
        var monthdata = [];
        function showGraph1

()

        {
            {
                $.post("mixedchart.php",
            
                function (data)
                {
                   // console.log(data);
                var dataRevenu = (data[1].slice(0,));
                var dataDepense = (data[0].slice(0,));
               // console.log(dataDepense);
                     var revenu = [];
                    var montantRevenu = [];
                    var depense = [];
                    var montantDepense = [];
                   
                    for (var i in dataRevenu) {
                        revenu.push(dataRevenu[i].date_revenu);
                       montantRevenu.push(dataRevenu[i].montant_r);
                    }
                    for (var i in dataDepense){
                        montantDepense.push(dataDepense[i].montant_d);
                       depense.push(dataDepense[i].date_depense);
                    }
                      
                      // var month = revenu[0].getMonth();
                   
                  //console.log(revenu[0]);
                  
                  for (var i=0; i<revenu.length; i++){
                    var state = new Date(revenu[i]);
                    //console.log(month.getMonth()+1);
                 
                   switch (state.getMonth()+1) {
  case 1:
    month = "Janvier";
    break;
  case 2:
    month = "Fevrier";
    break;
  case 3:
    month = "Mars";
    break;
  case 4:
    month = "Avril";
    break;
  case 5:
    month = "Mai";
    break;
  case 6:
    month = "Juin";
    break;
  case 7:
    month = "Juillet";
    break;
  case 8:
    month = "Aout";
    break;
  case 9:
    month = "Septembre";
    break;
  case 10:
    month = "Octobre";
    break;
  case 11:
    month = "Novembre";
    break;
  case 12:
    month = "Decembre";
}

console.log(month);
/*for (var i of month){
    monthdata.push(month[i]);
    console.log(monthdata);
}
break;
*/
//console.log(month);
/*for(var i in month){
                    //console.log(i);
                    month1.push(month[i]);
                     console.log(month1);

                  }*/
                 
 
                  }
                 
                  
                  
                  
                    

                    var chartdata = {
                        labels: depense,
                        datasets: [
                            {
                                label: 'Revenu',
                                backgroundColor: '#49e2ff',
                                borderColor: '#46d5f1',
                                borderWidth:1,
                                fill:'fasle',
                                hoverBorderWidth:4,
                                hoverBorderColor:'#000',
                                borderColor:'#777',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: montantRevenu
                            },
                            {
                                 label: "Depense",
                                 //new option, barline will default to bar as that what is used to create the scale
                                type: "line",
                                backgroundColor: 'red',
                                borderColor: 'black',
                                borderWidth:1,
                                fill:'false',
                                hoverBorderWidth:4,
                                hoverBorderColor:'#000',
                                borderColor:'#777',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: montantDepense
                            }
                        ] 
                    
                    };

                    var graphTarget = $("#graphCanvas1");

                    var barGraph = new Chart(graphTarget, {
                        type:'line',
                        data: chartdata
                    });
                });
            }
        }
        </script>
</article>

</div>
<div>
        <h1>Saisissez les d&#233;tails de vos d&#233;penses ici!</h1>
    
    

   
        <form action="depense.php" method="post">
            <label for="type_d">Type de D&#233;penses:</label>
            <br>
            <br>

            <select name="type_d" id="type_d">
                <option value="argent_de_poche">Argent de poche</option>
                <option value="remboursements">Remboursements</option>
                <option value="autres">Autres</option>
            </select>
            <br> <br>
            <br>
            <br>
            <br>
            <br>
            <br>
           

            

        
        <br><br><br>

        
            <label for="objet_d">Objet de D&#233;penses:</label>
            <br>
            <br>

            <select name="objet_d" id="objet_d">
                <option value="enfant">Enfant(s)</option>
                <option value="banque">Banque</option>
                <option value="electricite">&#201;lectricit&#233;</option>
                <option value="loyer">Loyer</option>
                <option value="autres_depenses">Autres d&#233;penses</option>
                
            </select>
            <br> <br>
            <br>
            <br>
            <br>
            <br>
            <br>
           

            

        

        
        <label for="date_depense">Date de d&#233;pense:</label><br><br>
        <input type="date" name="date_depense" id="date_depense">
        <br>
        <br>
        <label for="montant">Montant: (en gourdes)</label><br><br>
        <input type="number" name="montant" id="montant">
        <br>
        
        
        <br><br>

        <button type="submit" name="detail_depense">Valider</button>
        <button type="button" onclick="self.location.href='index.php'">Retour</button>
        <button type="button" onclick="self.location.href='liste_depense.php'">Voir la liste de vos d&#233;penses</button>

    </form>
   


    

</div>


<?php

    
include_once('connection.php');

$con = Connect();


if(isset($_POST['detail_depense'])){


//Insertion dans la table type de depense

$type= $_POST['type_d'];

//Requete SQL
$req1 = "CALL `insert_type_depense_pro`(:nom);";

//preparation de la requete
$stm1 = $con->prepare($req1);

//Passage des valeurs
$stm1->bindParam(":nom",$type);

//execution de la requete
$stm1->execute();





//Insertion dans la table type de revenu
$objet= $_POST['objet_d'];

 //Requete SQL
 $req2 = "CALL `insert_objet_depense_pro`(:nom);";

 //preparation de la requete
 $stm2 = $con->prepare($req2);

 //Passage des valeurs
 $stm2->bindParam(":nom",$objet);
 
 //execution de la requete
 $stm2->execute();






//Pour l'insertion dans la table depense

//la fonction insert_d s'occupe de l'insertion

function insert_de(){
    $con = Connect();

    $date_depense=$_POST['date_depense'];
    $montant=$_POST['montant'];

    //Requete SQL
    $req3 = "CALL `insert_depense_pro`(:date_de,:amount);";

    //preparation de la requete
    $stm3 = $con->prepare($req3);

    //Passage des valeurs
    $stm3->bindvalue(":date_de",$date_depense);
    $stm3->bindvalue(":amount",$montant);

    //execution de la requete
    $stm3->execute();

}


$montant=$_POST['montant'];

//Recuperation des montants se trouvant dans la table revenu
//afin de faire leur somme
$sql_revenu = "CALL `select_revenu`();";

$stm_revenu = $con->prepare($sql_revenu);

$stm_revenu->execute();

$revenus=$stm_revenu->fetchAll(PDO::FETCH_ASSOC);

$somme_revenu=0;

foreach($revenus as $revenu){

    $somme_revenu = $somme_revenu + $revenu['montant_r'];


}
//Recuperation des montants dans la table depense
//afin de faire leur somme
$sql_depense = "CALL `select_depense`();";

$stm_depense = $con->prepare($sql_depense);

$stm_depense->execute();

$depenses=$stm_depense->fetchAll(PDO::FETCH_ASSOC);

$somme_depense = 0;

foreach($depenses as $depense){

    $somme_depense=$somme_depense + $depense['montant_d'];

}
//Le montant disponible est le montant total des revenus moins
//le montant total des depenses effectues 
    $montant_dispo=$somme_revenu-$somme_depense;

    //Si l'utilisateur saisi un montant superieur
    //au montant disponible
    //Il est tout de suite alerte qu'il ne pourra pas en depenser
    //autant car il n'en dispose pas
    //parcontre, si le montant a depenser est inf ou egal
    //au montant dispo, il pourra.
    
    if($montant>$montant_dispo){
        echo "Vous ne pouvez pas depenser autant d'argent car vous n'en disposez pas!";
    }else{

        //appel a la fonction qui fait l'insertion dans la table depense
        insert_de();
    }

   
    

}

?>





    
    

    
</body>
</html>